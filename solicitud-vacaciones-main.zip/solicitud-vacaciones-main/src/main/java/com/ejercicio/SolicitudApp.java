package com.ejercicio;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SolicitudApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        
        Label lblTitulo = new Label("Solicitud de Vacaciones");
        lblTitulo.getStyleClass().add("label-titulo");
        
        HBox cabecera = new HBox(lblTitulo);
        cabecera.setAlignment(Pos.CENTER);
        cabecera.setPadding(new Insets(15));
        cabecera.getStyleClass().add("cabecera");

        
        Label lblSubtitulo = new Label("Sistema de Gestion Humana");
        lblSubtitulo.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #1e3a8a;");

        
        TextField txtNombreEmpleado = new TextField();
        TextField txtDepartamento = new TextField();
        TextField txtCargo = new TextField();
        TextField txtFechaInicio = new TextField();
        TextField txtFechaFin = new TextField();
        TextField txtMotivo = new TextField();

        VBox col1_f1 = new VBox(5, new Label("Nombre del empleado"), txtNombreEmpleado);
        VBox col2_f1 = new VBox(5, new Label("Departamento"), txtDepartamento);
        HBox fila1 = new HBox(30, col1_f1, col2_f1);

        VBox col1_f2 = new VBox(5, new Label("Cargo"), txtCargo);
        VBox col2_f2 = new VBox(5, new Label("Fecha de inicio (DD/MM/AAAA)"), txtFechaInicio);
        HBox fila2 = new HBox(30, col1_f2, col2_f2);

        
        VBox col1_f3 = new VBox(5, new Label("Fecha de fin (DD/MM/AAAA)"), txtFechaFin);
        VBox col2_f3 = new VBox(5, new Label("Motivo de la solicitud"), txtMotivo);
        HBox fila3 = new HBox(30, col1_f3, col2_f3);

        
        VBox contenedorFormulario = new VBox(20); 
        contenedorFormulario.setPadding(new Insets(20, 35, 25, 35));
        contenedorFormulario.getChildren().addAll(lblSubtitulo, fila1, fila2, fila3);
        contenedorFormulario.getStyleClass().add("formulario-central");

        
        Button btnGuardar = new Button("Guardar");
        Button btnLimpiar = new Button("Limpiar");
        btnGuardar.getStyleClass().add("btn-registrar"); 
        btnLimpiar.getStyleClass().add("btn-limpiar");  

        HBox contenedorBotones = new HBox(20, btnGuardar, btnLimpiar);
        contenedorBotones.setAlignment(Pos.CENTER);
        contenedorBotones.setPadding(new Insets(15));
        contenedorBotones.getStyleClass().add("panel-botones");

        btnGuardar.setOnAction(e -> {
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Registro Exitoso");
            alert.setHeaderText(null);
            alert.setContentText("La solicitud de vacaciones de '" + txtNombreEmpleado.getText() + "' fue registrada correctamente.");
            alert.showAndWait();
        });

        btnLimpiar.setOnAction(e -> {
            txtNombreEmpleado.clear();
            txtDepartamento.clear();
            txtCargo.clear();
            txtFechaInicio.clear();
            txtFechaFin.clear();
            txtMotivo.clear();
        });

       
        BorderPane root = new BorderPane();
        root.setTop(cabecera);
        root.setCenter(contenedorFormulario);
        root.setBottom(contenedorBotones);

      
        Scene scene = new Scene(root, 680, 430);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());

        primaryStage.setTitle("Recursos Humanos - Ejercicio 2");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}